module org.example.javafx14 {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.apache.poi.ooxml;
    requires java.sql;


    opens org.example.javafx14 to javafx.fxml;
    exports org.example.javafx14;
}