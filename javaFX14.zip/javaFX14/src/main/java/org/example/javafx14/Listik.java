package org.example.javafx14;

import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Listik {
    protected List<Integer> random() {
        List<Integer> randomList = new ArrayList<>();
        Random rand = new Random();
        for (int i = 0; i < 1000; i++) {
            randomList.add(rand.nextInt(10000)); // Генерация чисел от 0 до 9999
        }
        return randomList;
    }

    protected List<Integer> input() {
        Scanner scanner = new Scanner(System.in);
        List<Integer> inputList = new ArrayList<>();
        System.out.print("Введите минимальное значение: ");
        int min = scanner.nextInt();
        System.out.print("Введите максимальное значение: ");
        int max = scanner.nextInt();

        Random rand = new Random();
        for (int i = 0; i < 10000; i++) { // Фиксированный размер списка - 10000 элементов
            inputList.add(rand.nextInt(max - min + 1) + min);
        }

        System.out.print("Введите число для проверки наличия в списке: ");
        int check = scanner.nextInt();
        if (inputList.contains(check)) {
            System.out.println("Число присутствует в списке.");
        } else {
            System.out.println("Число отсутствует в списке.");
        }

        return inputList;
    }
}